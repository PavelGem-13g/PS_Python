# -*- coding: utf-8 -*-

import os

os.chdir("../Library")
import data_loader
import plots
import sorter

os.chdir("../Scripts")

# if __name__ == "__main__":
#     df = data_loader.get_database()
#     sorter.makeOutputs(df)
#     plots.generate_plots(df)

import webbrowser
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)
df = []

@app.route('/')
def upload_dataset():
    return render_template("index.html", message="")

@app.route('/senddataset', methods=['POST'])
def success():
    global df
    if request.method == 'POST':
        f = request.files['file']
        f.save(f.filename)
        os.replace(f.filename, "../Data/"+f.filename)
        df = data_loader.get_database(f.filename)
        # print(f.filename, data_loader.check_dataset(df))
        
        if(not data_loader.check_dataset(df)):
            # print("redirect")
            return render_template("index.html", message="Неверный датасет")
        
        return redirect('/work')

@app.route('/work')
def work_():
    global df
    plt = plots.generate_plots(df)
    return render_template("work.html", plots=plt)

if __name__=="__main__":
    webbrowser.open_new("http://127.0.0.1:5000/")
    app.run()
